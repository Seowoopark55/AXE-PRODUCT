import './styles.css';
import { envReady } from './lib/supabase.js';
import {
  getSession, refreshSession, signInWithDiscord, signOut, onAuthStateChange,
  listCompanies, createCompany, getMemberships, updateMembershipRole, updateMembershipStatus, updateMembershipAlias, updateMembershipEmploymentDate, updateMembershipNote, updateCompanyName,
  getModuleCatalog, getCompanyModules, setCompanyModule, updateCompanyModuleSettings,
  getCookingOrderTypes, saveCookingOrderType, setCookingOrderTypeEnabled, getCookingDiscordConfig, saveCookingDiscordGuide,
  getCompanySettings, updateCompanySettings,
  getDiscordConnection, getDiscordChannels, getDiscordRoles, getDiscordCompanyConfig, saveDiscordCompanyConfig,
  getFundAdminRequests, getFundAdminPeriodStatus, reviewFundRequest, setFundFeeRule, getFundEvidenceSignedUrl, uploadFundEvidence, removeUnclaimedFundEvidence,
  startDiscordConnection, startDiscordPermissionReapproval, completeDiscordConnection, createGuidedSetupChannels, listGuidedSetupMembers, bulkRegisterDiscordMembers, getCompanyOnboardingStatus, requestCompanyDiscordReconnect,
  getFundTreasurySnapshot, saveFundLedgerEntry, cancelFundLedgerEntry, getFundLedgerAttachments, attachFundLedgerEvidence,
  isPlatformAdmin, getPlatformCompanies, getCompanySubscription, updatePlatformSubscription,
  getWebAssetsSnapshot, saveWebAsset, manageWebAsset,
  getWebAccountsSnapshot, submitWebAccountRequest, reviewWebAccountRequest,
  submitProductFeedback,
} from './lib/productApi.js';
import { renderShell, canAdmin, currentMembership, moduleEnabled, moduleRow } from './ui/render.js';

const root = document.querySelector('#app');
const now = new Date();
const currentMonth = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
const validPages = ['fund','members','assets','accounts','settings','platform'];

const state = {
  envReady,
  session: null,
  companies: [],
  companyId: localStorage.getItem('axe_product_company_id') || null,
  memberships: [],
  moduleCatalog: [],
  modules: [],
  cookingOrderTypes: [],
  cookingDiscordConfig: null,
  companySettings: null,
  discordConnection: null,
  discordChannels: [],
  discordRoles: [],
  discordCompanyConfig: null,
  onboardingStatus: null,
  page: validPages.includes(localStorage.getItem('axe_product_page')) ? localStorage.getItem('axe_product_page') : 'fund',
  fundTab: localStorage.getItem('axe_product_fund_tab') || 'ledger',
  fundMonth: currentMonth,
  fundWeeklyMonth: currentMonth,
  currentMonth,
  fundSnapshot: null,
  fundRequests: [],
  fundMonthlyRows: [],
  fundWeeklyFee: 0,
  fundWeeklyLoading: false,
  fundFilters: { person:'all', type:'all', account:'all' },
  memberFilter: 'all', memberRole:'', memberQuery:'',
  assetTab: 'assets', assetQuery:'', assetCategory:'', assetStatus:'', assetsSnapshot:null,
  accountQuery:'', accountStatus:'', accountsSnapshot:null,
  platformAdmin:false, platformSnapshot:[], platformQuery:'', platformStatus:'all', currentSubscription:null,
  fundLedgerAttachments:[], ledgerPendingFiles:[],
  settingsTab: localStorage.getItem('axe_product_settings_tab') || 'basic',
  companyMenuOpen: false,
  modal: null,
  setupDemo: null,
  setupGuide: null,
  loading: false,
  ready: false,
  error: '',
  notice: '',
};

let noticeTimer = null;
let mutationBusy = false;
let reconnectPollTimer = null;
let reconnectPollAttempts = 0;
let catalogPollTimer = null;
let catalogPollAttempts = 0;
let sessionRecoveryBusy = false;
let lastSessionRecoveryAt = 0;
let manualSignOutUntil = 0;
let sessionHealthTimer = null;

function subscriptionEffectiveStatus(row){
  if(!row) return 'active';
  return String(row.effective_status||row.status||'active');
}
function subscriptionAllowsUse(row){
  return !['paused','expired'].includes(subscriptionEffectiveStatus(row));
}
function applyPlatformCompanyVisibility(){
  if(!state.platformAdmin || !(state.platformSnapshot||[]).length) return false;
  const blocked=new Set((state.platformSnapshot||[])
    .filter(row=>['paused','expired'].includes(String(row.effective_status||row.subscription_status||'')))
    .map(row=>String(row.company_id||'')));
  const previous=state.companyId;
  state.companies=(state.companies||[]).filter(company=>!blocked.has(String(company.id)));
  if(!state.companies.length){
    state.companyId=null;
    localStorage.removeItem('axe_product_company_id');
    clearCompanyData();
    return previous!==null;
  }
  if(!state.companies.some(company=>company.id===state.companyId)){
    state.companyId=state.companies[0].id;
    localStorage.setItem('axe_product_company_id',state.companyId);
    return previous!==state.companyId;
  }
  return false;
}
function clearLedgerPendingFiles(){
  for(const item of state.ledgerPendingFiles||[]){ try{ if(item.previewUrl) URL.revokeObjectURL(item.previewUrl); }catch{} }
  state.ledgerPendingFiles=[];
}
function addLedgerPendingFiles(files){
  const current=state.ledgerPendingFiles||[];
  const allowed=['image/jpeg','image/png','image/webp'];
  for(const file of Array.from(files||[])){
    if(!(file instanceof File) || !allowed.includes(file.type)) continue;
    if(file.size>10*1024*1024){ setError('사진 한 장은 10MB 이하만 첨부할 수 있습니다.'); continue; }
    if(current.length>=5){ setError('공금 내역에는 사진을 최대 5장까지 첨부할 수 있습니다.'); break; }
    current.push({id:crypto.randomUUID(),file,previewUrl:URL.createObjectURL(file)});
  }
  state.ledgerPendingFiles=current; render();
}
function ledgerEntryIdFromSave(saved){
  if(!saved) return '';
  if(typeof saved==='string') return saved;
  if(Array.isArray(saved)) return ledgerEntryIdFromSave(saved[0]);
  return String(saved.id||saved.entry_id||saved.ledger_entry_id||saved.data?.id||saved.data?.entry_id||'');
}
async function uploadLedgerPendingEvidence(entryId){
  if(!entryId || !(state.ledgerPendingFiles||[]).length) return;
  for(const item of state.ledgerPendingFiles){
    const path=await uploadFundEvidence(state.companyId,state.session.user.id,item.file);
    try{
      await attachFundLedgerEvidence(state.companyId,entryId,{storagePath:path,fileName:item.file.name||'clipboard-image',mimeType:item.file.type,sizeBytes:item.file.size});
    }catch(error){
      try{await removeUnclaimedFundEvidence(path);}catch{}
      throw error;
    }
  }
}
function createSetupDemoState(){
  return {
    step:0,
    connected:false,
    adminRole:'대표',
    memberRole:'회사원',
    modules:{fund:true,ammo:true,outlaw:false,modbook:true,cooking:false,assets:true},
    channelMode:'quick',
    categoryName:'AXE PRODUCT',
    channelsGenerated:false,
    generatedChannels:{fund:'공금현황판',ammo3:'3시-총알',ammo10:'10시-총알',outlaw:'전적-등록',modbook:'개조서',cooking:'요리-주문'},
    channels:{fund:'#공금현황판',ammo3:'#3시-총알',ammo10:'#10시-총알',outlaw:'#전적-등록',modbook:'#개조서',cooking:'#요리-주문'},
    memberFilter:'member',
    memberTargetRole:'member',
    memberSelected:['m1','m2','m3','m4','m5','m6'],
    memberImportDone:false,
    memberImportSkipped:false
  };
}

function createSetupGuideState(step = 0){
  const moduleMap={};
  for(const row of state.modules||[]) moduleMap[row.module_key]=Boolean(row.enabled);
  const settingsByKey={};
  for(const row of state.modules||[]) settingsByKey[row.module_key]=row.settings||{};
  const cfg=state.discordCompanyConfig||{};
  const roleRows=(state.discordRoles||[]).filter(r=>!r.managed&&r.role_name!=='@everyone');
  const memberFilterRoleId=String(cfg.member_role_id||roleRows[0]?.role_id||'');
  return {
    step:Math.max(0,Math.min(6,Number(step||0))),
    adminRoleId:String(cfg.admin_role_id||''),
    memberRoleId:String(cfg.member_role_id||''),
    modules:moduleMap,
    channelMode:'quick',
    categoryName:'AXE PRODUCT',
    generatedChannels:{fund:'공금현황판',ammo3:'3시-총알',ammo10:'10시-총알',outlaw:'전적-등록',modbook:'개조서',cooking:'요리-주문'},
    directChannels:{
      fund:String(settingsByKey.fund?.status_channel_id||''),
      ammo3:String(settingsByKey.ammo?.three_channel_id||''),
      ammo10:String(settingsByKey.ammo?.ten_channel_id||''),
      outlaw:String(settingsByKey.outlaw?.record_channel_id||''),
      modbook:String(settingsByKey.modbook?.channel_id||''),
      cooking:String(settingsByKey.cooking?.order_channel_id||''),
    },
    createdChannelIds:{},
    memberFilterRoleId,
    memberTargetRole:'member',
    memberCandidates:[],
    memberSelected:[],
    memberScanCount:0,
    memberListLoaded:false,
    memberImportDone:false,
    memberImportSkipped:false,
    permissionIssue:null,
    permissionMessage:'',
  };
}

function savedSetupGuideProgress(){
  const value=state.companySettings?.settings?.guided_setup;
  return value&&typeof value==='object'?value:null;
}

async function persistSetupGuideProgress(step,{completed=false}={}){
  if(!state.companyId||!state.session?.user?.id)return;
  const settings={...(state.companySettings?.settings||{}),guided_setup:{step:Math.max(0,Math.min(6,Number(step||0))),completed:Boolean(completed),updated_at:new Date().toISOString()}};
  await updateCompanySettings(state.companyId,{locale:state.companySettings?.locale||'ko-KR',timezone:state.companySettings?.timezone||'Asia/Seoul',settings},state.session.user.id);
  state.companySettings={...(state.companySettings||{}),settings};
}

function openSetupGuide(step = 0){
  state.setupGuide=createSetupGuideState(step);
  state.modal={type:'setup-guide'};
  render();
}

function setupGuideChannelPlan(){
  const modules=state.setupGuide?.modules||{};
  const rows=[];
  if(modules.fund)rows.push({key:'fund',moduleKey:'fund',settingKey:'status_channel_id',label:'공금 관리',name:state.setupGuide.generatedChannels?.fund||'공금현황판'});
  if(modules.ammo){
    rows.push({key:'ammo3',moduleKey:'ammo',settingKey:'three_channel_id',label:'총알 관리 · 3시',name:state.setupGuide.generatedChannels?.ammo3||'3시-총알'});
    rows.push({key:'ammo10',moduleKey:'ammo',settingKey:'ten_channel_id',label:'총알 관리 · 10시',name:state.setupGuide.generatedChannels?.ammo10||'10시-총알'});
  }
  if(modules.outlaw)rows.push({key:'outlaw',moduleKey:'outlaw',settingKey:'record_channel_id',label:'무법지대 전적',name:state.setupGuide.generatedChannels?.outlaw||'전적-등록'});
  if(modules.modbook)rows.push({key:'modbook',moduleKey:'modbook',settingKey:'channel_id',label:'개조서 조회 · 가격',name:state.setupGuide.generatedChannels?.modbook||'개조서'});
  if(modules.cooking)rows.push({key:'cooking',moduleKey:'cooking',settingKey:'order_channel_id',label:'요리 주문',name:state.setupGuide.generatedChannels?.cooking||'요리-주문'});
  return rows;
}

async function loadSetupGuideMembers(){
  if(!state.setupGuide || !state.companyId) return;
  const roleId=String(state.setupGuide.memberFilterRoleId||'');
  if(!roleId){state.setupGuide.memberCandidates=[];state.setupGuide.memberSelected=[];state.setupGuide.memberListLoaded=true;render();return;}
  const data=await listGuidedSetupMembers(state.companyId,roleId);
  const rows=Array.isArray(data?.members)?data.members:[];
  state.setupGuide.memberCandidates=rows;
  state.setupGuide.memberSelected=rows.map(row=>String(row.discord_user_id));
  state.setupGuide.memberScanCount=Number(data?.scanned||rows.length);
  state.setupGuide.memberListLoaded=true;
  render();
}

async function saveSetupGuideRoles(){
  if(!state.setupGuide) return;
  const adminRoleId=String(state.setupGuide.adminRoleId||'');
  const memberRoleId=String(state.setupGuide.memberRoleId||'');
  if(!adminRoleId||!memberRoleId) throw new Error('관리자 역할과 일반 멤버 역할을 모두 선택해 주세요.');
  await saveDiscordCompanyConfig(state.companyId,{
    notification_channel_id:state.discordCompanyConfig?.notification_channel_id||null,
    command_channel_id:state.discordCompanyConfig?.command_channel_id||null,
    admin_role_id:adminRoleId,
    member_role_id:memberRoleId,
  },state.session.user.id);
  await loadBaseCompanyData();
  state.setupGuide={...createSetupGuideState(3),modules:{...(state.setupGuide?.modules||{})},adminRoleId,memberRoleId};
}

async function saveSetupGuideModules(){
  if(!state.setupGuide) return;
  for(const row of state.modules||[]){
    if(!Object.prototype.hasOwnProperty.call(state.setupGuide.modules||{},row.module_key)) continue;
    const enabled=Boolean(state.setupGuide.modules[row.module_key]);
    if(Boolean(row.enabled)!==enabled) await setCompanyModule(state.companyId,row.module_key,enabled,state.session.user.id);
  }
  await loadBaseCompanyData();
  const previous=state.setupGuide;
  const next=createSetupGuideState(4);
  next.channelMode=previous.channelMode||'quick';
  next.categoryName=previous.categoryName||'AXE PRODUCT';
  next.generatedChannels={...(previous.generatedChannels||next.generatedChannels)};
  state.setupGuide=next;
}

function setupGuideChannelBinding(key){
  const map={
    fund:['fund','status_channel_id'],
    ammo3:['ammo','three_channel_id'],
    ammo10:['ammo','ten_channel_id'],
    outlaw:['outlaw','record_channel_id'],
    modbook:['modbook','channel_id'],
    cooking:['cooking','order_channel_id'],
  };
  return map[key]||null;
}

async function persistSetupGuideChannels(channelMap){
  const grouped=new Map();
  for(const [key,channelId] of Object.entries(channelMap||{})){
    const binding=setupGuideChannelBinding(key); if(!binding||!channelId)continue;
    const [moduleKey,settingKey]=binding;
    if(!grouped.has(moduleKey)) grouped.set(moduleKey,{});
    grouped.get(moduleKey)[settingKey]=String(channelId);
  }
  for(const [moduleKey,patch] of grouped){
    const row=(state.modules||[]).find(m=>m.module_key===moduleKey); if(!row)continue;
    await updateCompanyModuleSettings(state.companyId,moduleKey,{...(row.settings||{}),...patch},state.session.user.id);
  }
  await loadBaseCompanyData();
}

async function cleanupLegacyPwa() {
  try {
    if ('serviceWorker' in navigator) {
      const registrations = await navigator.serviceWorker.getRegistrations();
      await Promise.all(registrations.map((registration) => registration.unregister()));
    }
    if ('caches' in window) {
      const keys = await caches.keys();
      await Promise.all(keys.filter((key) => key.startsWith('axe-product-pwa-')).map((key) => caches.delete(key)));
    }
  } catch (error) {
    console.warn('AXE PRODUCT legacy PWA cleanup failed', error);
  }
}

function suppressBrowserFormHistory() {
  root.querySelectorAll('form').forEach(form => form.setAttribute('autocomplete','off'));
  root.querySelectorAll('input, textarea').forEach(field => {
    if (!field.hasAttribute('autocomplete')) field.setAttribute('autocomplete','off');
    field.setAttribute('autocorrect','off');
    field.setAttribute('autocapitalize','off');
    field.setAttribute('spellcheck','false');
  });
}
function render() { renderShell(root, state); suppressBrowserFormHistory(); }
function setNotice(message) {
  state.notice = String(message || ''); state.error = ''; render();
  if (noticeTimer) clearTimeout(noticeTimer);
  if (state.notice) noticeTimer = setTimeout(() => {
    state.notice = '';
    // Do not re-render the whole app just to hide a notice. A full root.innerHTML
    // replacement closes an open native <select>, which made role/channel
    // dropdowns appear to close by themselves a few seconds after catalog load.
    root.querySelector('.runtime-banner--notice')?.remove();
  }, 3200);
}
function setError(error) { state.error = String(error?.message || error || '오류가 발생했습니다.'); render(); }
function clearCompanyData() {
  state.memberships=[]; state.moduleCatalog=[]; state.modules=[]; state.cookingOrderTypes=[]; state.cookingDiscordConfig=null; state.companySettings=null;
  state.discordConnection=null; state.discordChannels=[]; state.discordRoles=[]; state.discordCompanyConfig=null; state.onboardingStatus=null;
  state.fundSnapshot=null; state.fundRequests=[]; state.fundMonthlyRows=[]; state.fundLedgerAttachments=[]; state.assetsSnapshot=null; state.accountsSnapshot=null; state.currentSubscription=null;
}

async function loadCompanies() {
  state.companies = await listCompanies();
  if (!state.companies.length) { state.companyId=null; localStorage.removeItem('axe_product_company_id'); clearCompanyData(); return; }
  if (!state.companies.some(c=>c.id===state.companyId)) state.companyId=state.companies[0].id;
  localStorage.setItem('axe_product_company_id', state.companyId);
}

async function loadBaseCompanyData() {
  if (!state.companyId) { clearCompanyData(); return; }
  const memberships = await getMemberships(state.companyId);
  state.memberships = memberships || [];
  const [catalog, modules, cookingTypes, cookingConfig, settings, discord, channels, roles, config, onboarding, subscription] = await Promise.all([
    getModuleCatalog(), getCompanyModules(state.companyId), getCookingOrderTypes(state.companyId), getCookingDiscordConfig(state.companyId), getCompanySettings(state.companyId),
    getDiscordConnection(state.companyId), getDiscordChannels(state.companyId), getDiscordRoles(state.companyId), getDiscordCompanyConfig(state.companyId),
    getCompanyOnboardingStatus(state.companyId),
    getCompanySubscription(state.companyId).catch(()=>null),
  ]);
  state.moduleCatalog=catalog||[]; state.modules=modules||[]; state.cookingOrderTypes=cookingTypes||[]; state.cookingDiscordConfig=cookingConfig||null; state.companySettings=settings||null;
  state.discordConnection=discord||null; state.discordChannels=channels||[]; state.discordRoles=roles||[]; state.discordCompanyConfig=config||null; state.onboardingStatus=onboarding||null; state.currentSubscription=subscription||null;
}

async function loadFundSnapshot() {
  if (!canAdmin(state) || !moduleEnabled(state,'fund')) { state.fundSnapshot=null; state.fundRequests=[]; return; }
  const [y,m] = state.fundMonth.split('-').map(Number);
  const [snapshot, requests, attachments] = await Promise.all([
    getFundTreasurySnapshot(state.companyId,y,m,200),
    getFundAdminRequests(state.companyId,null,100),
    getFundLedgerAttachments(state.companyId,null).catch(()=>[]),
  ]);
  state.fundSnapshot=snapshot||{}; state.fundRequests=requests||[]; state.fundLedgerAttachments=attachments||[];
}

function fundWeekNumbersForMonth(year, month) {
  const safeYear=Number(year);
  const safeMonth=Number(month);
  const lastDay=new Date(Date.UTC(safeYear,safeMonth,0)).getUTCDate();
  const weeks=[];
  for(let day=1;day<=lastDay;day+=1){
    if(new Date(Date.UTC(safeYear,safeMonth-1,day)).getUTCDay()===6) weeks.push(weeks.length+1);
  }
  return weeks;
}

async function loadFundWeeklyMonth(monthValue = state.fundWeeklyMonth) {
  if (!canAdmin(state) || !moduleEnabled(state,'fund')) { state.fundMonthlyRows=[]; return; }
  state.fundWeeklyLoading=true; render();
  const [year,month]=String(monthValue).split('-').map(Number);
  const weekNumbers=fundWeekNumbersForMonth(year,month);
  const results = await Promise.all(weekNumbers.map(async week => {
    try { return await getFundAdminPeriodStatus(state.companyId,year,month,week); } catch { return []; }
  }));
  const map=new Map(); let fee=0;
  results.forEach((weekRows,index)=>{
    for(const row of weekRows||[]){
      const key=row.membership_id || row.display_name;
      if(!map.has(key)) map.set(key,{name:row.display_name||'멤버',role:(row.member_role||'member').toUpperCase(),weeks:['예정','예정','예정','예정','예정']});
      map.get(key).weeks[index]=row.status||'예정';
      if(!fee && Number(row.expected_amount)>0) fee=Number(row.expected_amount);
    }
  });
  state.fundMonthlyRows=[...map.values()]; state.fundWeeklyFee=fee; state.fundWeeklyLoading=false; render();
}

async function loadAssetsAndAccounts() {
  if (!canAdmin(state) || !moduleEnabled(state,'assets')) { state.assetsSnapshot=null; state.accountsSnapshot=null; return; }
  const [assets, accounts] = await Promise.all([getWebAssetsSnapshot(state.companyId), getWebAccountsSnapshot(state.companyId)]);
  state.assetsSnapshot=assets||{}; state.accountsSnapshot=accounts||{};
}

async function loadCompanyData() {
  await loadBaseCompanyData();
  if (canAdmin(state)) {
    const jobs=[];
    if (moduleEnabled(state,'fund')) jobs.push(loadFundSnapshot());
    if (moduleEnabled(state,'assets')) jobs.push(loadAssetsAndAccounts());
    await Promise.all(jobs);
    if (state.fundTab==='weekly' && moduleEnabled(state,'fund')) await loadFundWeeklyMonth(state.fundWeeklyMonth);
  }
}

async function refreshAll() {
  if (!state.session?.user) { state.ready=true; render(); return; }
  state.loading=true; state.error=''; render();
  try {
    state.platformAdmin=await isPlatformAdmin().catch(()=>false);
    if(!state.platformAdmin && state.page==='platform'){state.page='fund';localStorage.setItem('axe_product_page','fund');}
    await loadCompanies();
    state.platformSnapshot=state.platformAdmin?await getPlatformCompanies().catch(()=>[]):[];
    applyPlatformCompanyVisibility();
    await loadCompanyData();
    state.ready=true;
  }
  catch(error){ state.error=String(error?.message||error); }
  finally { state.loading=false; render(); }
}

function clearReconnectPoll() {
  if (reconnectPollTimer) clearTimeout(reconnectPollTimer);
  reconnectPollTimer = null;
  reconnectPollAttempts = 0;
}

function clearCatalogPoll() {
  if (catalogPollTimer) clearTimeout(catalogPollTimer);
  catalogPollTimer = null;
  catalogPollAttempts = 0;
}

function discordCatalogPending(status = state.onboardingStatus) {
  return state.discordConnection?.status === 'connected' && status?.catalog_ready === false;
}

function startCatalogStatusPoll() {
  clearCatalogPoll();
  const run = async () => {
    if (!state.companyId || !state.session?.user) return clearCatalogPoll();
    catalogPollAttempts += 1;
    try {
      const status = await getCompanyOnboardingStatus(state.companyId);
      state.onboardingStatus = status || null;
      if (!status?.discord_connected) {
        clearCatalogPoll();
        render();
        return;
      }
      if (status?.catalog_ready === true) {
        clearCatalogPoll();
        await loadBaseCompanyData();
        if(state.modal?.type==='setup-guide' && Number(state.setupGuide?.step||0)<=1){
          state.setupGuide=createSetupGuideState(2);
          render();
        }
        setNotice(`Discord 역할 ${Number(status.role_count||0)}개 · 채널 ${Number(status.channel_count||0)}개를 불러왔습니다.`);
        return;
      }
      render();
    } catch (error) {
      if (catalogPollAttempts >= 30) {
        clearCatalogPoll();
        setError(error);
        return;
      }
    }
    if (catalogPollAttempts < 30) catalogPollTimer=setTimeout(run,2000);
    else {
      clearCatalogPoll();
      setNotice('Discord 역할·채널 동기화가 지연되고 있습니다. 잠시 후 새로고침해 주세요.');
    }
  };
  catalogPollTimer=setTimeout(run,600);
}

function startReconnectStatusPoll() {
  clearReconnectPoll();
  const run = async () => {
    if (!state.companyId || !state.session?.user) return clearReconnectPoll();
    reconnectPollAttempts += 1;
    try {
      const status = await getCompanyOnboardingStatus(state.companyId);
      state.onboardingStatus = status || null;
      const phase = String(status?.status || '');
      if (phase === 'error') {
        clearReconnectPoll();
        setError(status?.last_error || 'Discord 연결 초기화에 실패했습니다.');
        return;
      }
      if (!['reset_requested','resetting'].includes(phase)) {
        clearReconnectPoll();
        await loadBaseCompanyData();
        state.settingsTab='basic';
        localStorage.setItem('axe_product_settings_tab','basic');
        setNotice('기존 Discord 연결 정리가 완료됐습니다. 다시 연결할 수 있습니다.');
        return;
      }
      render();
    } catch (error) {
      if (reconnectPollAttempts >= 20) {
        clearReconnectPoll();
        setError(error);
        return;
      }
    }
    if (reconnectPollAttempts < 20) reconnectPollTimer=setTimeout(run,2500);
    else { clearReconnectPoll(); setNotice('Discord 연결 정리가 진행 중입니다. 잠시 후 새로고침해 주세요.'); }
  };
  reconnectPollTimer=setTimeout(run,1200);
}

function discordOAuthErrorMessage(code) {
  const map={access_denied:'Discord 서버 연결이 취소됐습니다.',invalid_request:'Discord 인증 요청이 올바르지 않습니다.',temporarily_unavailable:'Discord 인증 서비스를 잠시 사용할 수 없습니다.',token_exchange_failed:'Discord 인증 코드 교환에 실패했습니다.',guild_not_returned:'선택한 Discord 서버 정보를 확인하지 못했습니다.',guild_mismatch:'권한을 승인한 Discord 서버가 현재 연결된 회사 서버와 다릅니다.',oauth_validation_failed:'Discord 인증 보안 검증에 실패했습니다.',missing_oauth_response:'Discord 인증 결과가 비어 있습니다.',oauth_failed:'Discord 서버 연결에 실패했습니다.'};
  return map[code]||'Discord 서버 연결에 실패했습니다.';
}
async function handleDiscordOAuthReturn() {
  const raw=String(location.hash||'').replace(/^#/,''); if(!raw)return;
  const params=new URLSearchParams(raw); const token=params.get('discord_link'); const error=params.get('discord_error');
  if(!token&&!error)return; history.replaceState(null,'',`${location.pathname}${location.search}`);
  if(error) throw new Error(discordOAuthErrorMessage(error));
  if(!state.session?.user) throw new Error('Discord 서버 연결을 완료하려면 다시 로그인해 주세요.');
  const connection=await completeDiscordConnection(token); clearReconnectPoll(); clearCatalogPoll(); state.companyId=connection.company_id; localStorage.setItem('axe_product_company_id',state.companyId); await refreshAll(); state.page='settings'; state.settingsTab='basic'; localStorage.setItem('axe_product_page','settings'); localStorage.setItem('axe_product_settings_tab','basic');
  const resumeGuide=localStorage.getItem('axe_product_setup_resume')==='1';
  const resumeStepRaw=Number(localStorage.getItem('axe_product_setup_resume_step'));
  localStorage.removeItem('axe_product_setup_resume');
  localStorage.removeItem('axe_product_setup_resume_step');
  if(resumeGuide){
    const resumeStep=Number.isInteger(resumeStepRaw)&&resumeStepRaw>=0&&resumeStepRaw<=6?resumeStepRaw:(discordCatalogPending()?1:2);
    state.setupGuide=createSetupGuideState(resumeStep);
    state.modal={type:'setup-guide'};
    render();
  }
  if(discordCatalogPending()){setNotice(`Discord 서버 ${connection.guild_name||''} 연결 완료 · 역할·채널 정보를 불러오는 중입니다.`);startCatalogStatusPoll();}
  else setNotice(`Discord 서버 ${connection.guild_name||''} 연결이 완료됐습니다.`);
}

async function recoverSessionOnResume({force=false}={}) {
  if(!envReady || document.visibilityState==='hidden' || sessionRecoveryBusy) return;
  const nowMs=Date.now();
  if(!force && nowMs-lastSessionRecoveryAt<8000) return;
  sessionRecoveryBusy=true; lastSessionRecoveryAt=nowMs;
  try{
    let session=await getSession();
    const expiresAt=Number(session?.expires_at||0)*1000;
    if(session && (!expiresAt || expiresAt-nowMs<5*60*1000)){
      try{session=await refreshSession()||session;}catch(error){console.warn('AXE PRODUCT session refresh deferred',error);}
    }
    if(!session){
      try{session=await refreshSession();}catch(error){
        const msg=String(error?.message||error||'');
        if(!/session.*missing|refresh.*token.*not found|invalid refresh/i.test(msg)) throw error;
      }
    }
    if(session?.user){
      const before=state.session?.user?.id||null; const after=session.user.id;
      state.session=session;
      if(before!==after || !state.ready){state.ready=false;await refreshAll();}
      return;
    }
    if(state.session?.user){state.session=null;clearCompanyData();state.ready=true;render();}
  }catch(error){
    console.warn('AXE PRODUCT session recovery skipped after transient error',error);
  }finally{sessionRecoveryBusy=false;}
}

function installSessionResumeRecovery(){
  document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')recoverSessionOnResume({force:true});});
  window.addEventListener('focus',()=>recoverSessionOnResume());
  window.addEventListener('online',()=>recoverSessionOnResume({force:true}));
  if(sessionHealthTimer)clearInterval(sessionHealthTimer);
  sessionHealthTimer=setInterval(()=>{if(document.visibilityState==='visible'&&state.session?.user)recoverSessionOnResume();},10*60*1000);
}

async function boot() {
  if(!envReady){state.ready=true;render();return;}
  try{state.session=await getSession();if(state.session){const exp=Number(state.session.expires_at||0)*1000;if(!exp||exp-Date.now()<5*60*1000)state.session=await refreshSession()||state.session;}}catch(error){state.error=String(error?.message||error);} render(); await refreshAll();
  installSessionResumeRecovery();
  if(discordCatalogPending()) startCatalogStatusPoll();
  try{await handleDiscordOAuthReturn();}catch(error){setError(error);}
  onAuthStateChange((event,session)=>{
    setTimeout(async()=>{
      if(event==='SIGNED_OUT' && Date.now()>manualSignOutUntil){await recoverSessionOnResume({force:true});return;}
      const before=state.session?.user?.id||null; const after=session?.user?.id||null;
      state.session=session;
      if(before!==after){state.ready=false;await refreshAll();}
    },0);
  });
}

function closeModal({force=false}={}) {
  if(state.modal?.type==='feedback' && !force){
    const form=root.querySelector('form[data-form="feedback"]');
    const dirty=form && [...form.querySelectorAll('input,textarea')].some(el=>String(el.value||'').trim());
    if(dirty && !window.confirm('작성 중인 피드백 내용이 사라질 수 있습니다. 닫을까요?')) return false;
  }
  if(state.modal?.type==='setup-demo') state.setupDemo=null; if(state.modal?.type==='setup-guide') state.setupGuide=null; if(['ledger','ledger-correction'].includes(state.modal?.type)) clearLedgerPendingFiles(); state.modal=null; render(); return true;
}

async function withMutation(fn){ if(mutationBusy)return; mutationBusy=true; state.loading=true; render(); try{await fn();}catch(error){setError(error);}finally{mutationBusy=false;state.loading=false;render();} }

function onboardingPhase(){ return String(state.onboardingStatus?.status||''); }
function onboardingStep(){ return String(state.onboardingStatus?.current_step||''); }
function isOnboardingStep(step){ return onboardingPhase()==='onboarding' && onboardingStep()===step; }

function assertOnboardingRoles(data){
  if(!isOnboardingStep('roles')) return;
  if(discordCatalogPending()) throw new Error('Discord 역할·채널 정보를 불러오는 중입니다. 잠시만 기다려 주세요.');
  if(!String(data.get('admin_role_id')||'').trim()) throw new Error('관리자 역할을 선택해 주세요.');
  if(!String(data.get('member_role_id')||'').trim()) throw new Error('일반 멤버 역할을 선택해 주세요.');
}

async function saveBasicSettingsData(data,{requireOnboardingRoles=false}={}){
  if(requireOnboardingRoles) assertOnboardingRoles(data);
  const companyName=String(data.get('company_name')||'').trim();
  if(!companyName) throw new Error('회사 이름을 입력해 주세요.');
  if(companyName!==(state.companies.find(c=>c.id===state.companyId)?.name||'')) await updateCompanyName(state.companyId,companyName);
  let settings={...(state.companySettings?.settings||{})};
  await updateCompanySettings(state.companyId,{locale:state.companySettings?.locale||'ko-KR',timezone:state.companySettings?.timezone||'Asia/Seoul',settings},state.session.user.id);
  await saveDiscordCompanyConfig(state.companyId,{notification_channel_id:state.discordCompanyConfig?.notification_channel_id||null,command_channel_id:state.discordCompanyConfig?.command_channel_id||null,admin_role_id:String(data.get('admin_role_id')||'')||null,member_role_id:String(data.get('member_role_id')||'')||null},state.session.user.id);
}

async function saveModuleSettingsData(form,data){
  for(const mod of state.modules){
    const settings={...(mod.settings||{})};
    for(const key of ['status_channel_id','three_channel_id','ten_channel_id','record_channel_id','channel_id','order_channel_id']){
      const field=`module_${mod.module_key}_${key}`; if(form.elements[field])settings[key]=String(data.get(field)||'')||null;
    }
    await updateCompanyModuleSettings(state.companyId,mod.module_key,settings,state.session.user.id);
  }
}

root.addEventListener('click', async event => {
  const pageBtn=event.target.closest('[data-page]');
  if(pageBtn){ state.page=pageBtn.dataset.page; localStorage.setItem('axe_product_page',state.page); if(state.page==='fund'&&!state.fundSnapshot) await withMutation(loadFundSnapshot); if(['assets','accounts'].includes(state.page)&&!state.assetsSnapshot) await withMutation(loadAssetsAndAccounts); if(state.page==='platform'&&state.platformAdmin) state.platformSnapshot=await getPlatformCompanies().catch(()=>state.platformSnapshot||[]); render(); return; }
  const fundTab=event.target.closest('[data-fund-tab]');
  if(fundTab){state.fundTab=fundTab.dataset.fundTab;localStorage.setItem('axe_product_fund_tab',state.fundTab);render();if(state.fundTab==='weekly') await loadFundWeeklyMonth();return;}
  const memberFilter=event.target.closest('[data-member-filter]'); if(memberFilter){state.memberFilter=memberFilter.dataset.memberFilter;render();return;}
  const assetTab=event.target.closest('[data-asset-tab]'); if(assetTab){state.assetTab=assetTab.dataset.assetTab;render();return;}
  const settingsTab=event.target.closest('[data-settings-tab]');
  if(settingsTab){
    const nextTab=String(settingsTab.dataset.settingsTab||'basic');
    if(nextTab==='modules' && state.settingsTab==='basic' && isOnboardingStep('roles')){
      if(discordCatalogPending()){setError('Discord 역할·채널 정보를 불러오는 중입니다. 잠시만 기다려 주세요.');startCatalogStatusPoll();return;}
      const activeForm=root.querySelector('form[data-form="settings-basic"]');
      if(!activeForm){setError('기본 설정 화면을 다시 열어 주세요.');return;}
      const activeData=new FormData(activeForm);
      await withMutation(async()=>{
        await saveBasicSettingsData(activeData,{requireOnboardingRoles:true});
        await loadBaseCompanyData();
        state.settingsTab='modules';
        localStorage.setItem('axe_product_settings_tab','modules');
        setNotice('역할 설정을 저장했습니다. 기능·채널 설정으로 이동합니다.');
      });
      return;
    }
    if(nextTab==='modules' && state.settingsTab==='basic' && isOnboardingStep('discord')){
      setError('먼저 Discord 서버를 연결해 주세요.');
      return;
    }
    state.settingsTab=nextTab;localStorage.setItem('axe_product_settings_tab',state.settingsTab);render();return;
  }
  if(event.target.matches('[data-modal-backdrop]')){ if(['feedback','cooking-menu'].includes(state.modal?.type))return; closeModal(); return; }

  const actionEl=event.target.closest('[data-action]'); if(!actionEl)return; const action=actionEl.dataset.action;
  if(action==='toggle-company-menu'){state.companyMenuOpen=!state.companyMenuOpen;render();return;}
  if(action==='switch-company'){const next=String(actionEl.dataset.companyId||'');clearReconnectPoll();clearCatalogPoll();state.companyMenuOpen=false;if(!next||next===state.companyId){render();return;}state.companyId=next;localStorage.setItem('axe_product_company_id',next);state.fundSnapshot=null;state.fundLedgerAttachments=[];state.assetsSnapshot=null;state.accountsSnapshot=null;state.fundMonthlyRows=[];await withMutation(loadCompanyData);return;}
  if(action==='dismiss-error'){state.error='';render();return;}
  if(action==='close-modal'){closeModal();return;}
  if(action==='open-create-company'){state.modal={type:'create-company'};render();return;}
  if(action==='open-setup-guide'){
    if(!canAdmin(state)){setError('초기설정은 OWNER 또는 관리자만 진행할 수 있습니다.');return;}
    const saved=savedSetupGuideProgress();
    let step=saved&&!saved.completed?Math.max(0,Math.min(6,Number(saved.step||0))):0;
    if(state.discordConnection?.status!=='connected'||state.onboardingStatus?.catalog_ready===false) step=1;
    else if(!state.discordCompanyConfig?.admin_role_id||!state.discordCompanyConfig?.member_role_id) step=Math.min(step||2,2)||2;
    else if(String(state.onboardingStatus?.status||'')==='onboarding'&&String(state.onboardingStatus?.current_step||'')==='modules') step=Math.max(step,3);
    openSetupGuide(step); return;
  }
  if(action==='setup-guide-back'){if(!state.setupGuide)return;state.setupGuide.step=Math.max(0,Number(state.setupGuide.step||0)-1);render();return;}
  if(action==='setup-guide-jump'){if(!state.setupGuide)return;const target=Number(actionEl.dataset.step||0);if(target<=Number(state.setupGuide.step||0)){state.setupGuide.step=Math.max(0,Math.min(6,target));render();}return;}
  if(action==='setup-guide-next'){
    if(!state.setupGuide)return;
    const step=Number(state.setupGuide.step||0);
    if(step===1){if(state.discordConnection?.status!=='connected'){setError('먼저 Discord 서버를 연결해 주세요.');return;}if(state.onboardingStatus?.catalog_ready===false){setError('Discord 역할·채널 정보를 불러오는 중입니다. 잠시만 기다려 주세요.');startCatalogStatusPoll();return;}}
    state.setupGuide.step=Math.min(6,step+1);await withMutation(async()=>{await persistSetupGuideProgress(state.setupGuide.step);});return;
  }
  if(action==='setup-guide-connect'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{localStorage.setItem('axe_product_setup_resume','1');localStorage.removeItem('axe_product_setup_resume_step');const started=await startDiscordConnection(state.companyId);location.assign(started.authorize_url);});return;
  }
  if(action==='setup-guide-reapprove-channels'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{
      localStorage.setItem('axe_product_setup_resume','1');
      localStorage.setItem('axe_product_setup_resume_step','4');
      const started=await startDiscordPermissionReapproval(state.companyId);
      location.assign(started.authorize_url);
    });return;
  }
  if(action==='setup-guide-save-roles'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{await saveSetupGuideRoles();await persistSetupGuideProgress(3);setNotice('Discord 역할 설정을 저장했습니다.');});return;
  }
  if(action==='setup-guide-toggle-module'){
    if(!state.setupGuide)return;const key=String(actionEl.dataset.moduleKey||'');if(Object.prototype.hasOwnProperty.call(state.setupGuide.modules||{},key)){state.setupGuide.modules[key]=!state.setupGuide.modules[key];render();}return;
  }
  if(action==='setup-guide-save-modules'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{await saveSetupGuideModules();await persistSetupGuideProgress(4);setNotice('사용 기능을 저장했습니다.');});return;
  }
  if(action==='setup-guide-channel-mode'){if(!state.setupGuide)return;state.setupGuide.channelMode=String(actionEl.dataset.mode||'quick')==='direct'?'direct':'quick';if(state.setupGuide.channelMode==='direct'){state.setupGuide.permissionIssue=null;state.setupGuide.permissionMessage='';}render();return;}
  if(action==='setup-guide-create-channels'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{
      const plan=setupGuideChannelPlan();
      const category=String(state.setupGuide.categoryName||'AXE PRODUCT').trim();
      if(!category)throw new Error('카테고리 이름을 입력해 주세요.');
      if(plan.some(row=>!String(row.name||'').trim()))throw new Error('생성할 채널 이름을 모두 입력해 주세요.');
      const normalizedNames=plan.map(row=>String(row.name||'').trim().toLocaleLowerCase('ko-KR'));
      if(new Set(normalizedNames).size!==normalizedNames.length)throw new Error('같은 채널명을 두 번 사용할 수 없습니다. 채널명을 다르게 지정해 주세요.');
      let result;
      try{
        result=await createGuidedSetupChannels(state.companyId,category,plan.map(row=>({key:row.key,name:row.name})));
      }catch(error){
        const message=String(error?.message||error||'');
        if(Number(error?.statusCode||0)===403 || /채널 관리 권한/.test(message)){
          state.setupGuide.permissionIssue='manage_channels';
          state.setupGuide.permissionMessage='AXE가 Discord 채널을 자동 생성하려면 현재 연결된 서버에서 채널 관리 권한 승인이 필요합니다.';
          render();
          return;
        }
        throw error;
      }
      state.setupGuide.permissionIssue=null;
      state.setupGuide.permissionMessage='';
      const map={};for(const row of result?.channels||[])if(row?.key&&row?.id)map[String(row.key)]=String(row.id);
      await persistSetupGuideChannels(map);
      state.setupGuide=createSetupGuideState(5);await persistSetupGuideProgress(5);
      setNotice(`${Object.keys(map).length}개 Discord 채널을 준비하고 기능에 연결했습니다.`);
    });return;
  }
  if(action==='setup-guide-save-direct-channels'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{
      const plan=setupGuideChannelPlan(); const map={};
      for(const row of plan){const id=String(state.setupGuide.directChannels?.[row.key]||'');if(!id)throw new Error(`${row.label}에 연결할 Discord 채널을 선택해 주세요.`);map[row.key]=id;}
      await persistSetupGuideChannels(map);state.setupGuide=createSetupGuideState(5);await persistSetupGuideProgress(5);setNotice('기존 Discord 채널을 AXE 기능에 연결했습니다.');
    });return;
  }
  if(action==='setup-guide-load-members'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(loadSetupGuideMembers);return;
  }
  if(action==='setup-guide-select-members'){
    if(!state.setupGuide)return;const ids=(state.setupGuide.memberCandidates||[]).map(m=>String(m.discord_user_id));const selected=new Set((state.setupGuide.memberSelected||[]).map(String));const all=ids.length>0&&ids.every(id=>selected.has(id));ids.forEach(id=>all?selected.delete(id):selected.add(id));state.setupGuide.memberSelected=[...selected];render();return;
  }
  if(action==='setup-guide-import-members'){
    if(!state.setupGuide||!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}
    await withMutation(async()=>{
      const selected=new Set((state.setupGuide.memberSelected||[]).map(String));const members=(state.setupGuide.memberCandidates||[]).filter(m=>selected.has(String(m.discord_user_id)));
      if(!members.length)throw new Error('등록할 멤버를 한 명 이상 선택해 주세요.');
      const result=await bulkRegisterDiscordMembers(state.companyId,state.setupGuide.memberFilterRoleId,members.map(m=>String(m.discord_user_id)),state.setupGuide.memberTargetRole||'member');
      await loadBaseCompanyData();state.setupGuide.memberImportDone=true;state.setupGuide.memberImportSkipped=false;await persistSetupGuideProgress(6);setNotice(`${Number(result?.inserted?.length||0)}명 등록 완료 · ${Number(result?.skipped?.length||0)}명 기존 등록`);
    });return;
  }
  if(action==='setup-guide-skip-members'){if(!state.setupGuide)return;state.setupGuide.memberImportDone=true;state.setupGuide.memberImportSkipped=true;await withMutation(async()=>{await persistSetupGuideProgress(6);});return;}
  if(action==='setup-guide-finish'){await withMutation(async()=>{await persistSetupGuideProgress(6,{completed:true});state.setupGuide=null;state.modal=null;state.page='fund';localStorage.setItem('axe_product_page','fund');setNotice('초기설정이 완료됐습니다.');});return;}
  if(action==='open-setup-demo'){state.setupDemo=createSetupDemoState();state.modal={type:'setup-demo'};render();return;}
  if(action==='setup-demo-connect'){if(!state.setupDemo)return;state.setupDemo.connected=true;render();return;}
  if(action==='setup-demo-next'){if(!state.setupDemo)return;if(state.setupDemo.step===1&&!state.setupDemo.connected){state.setupDemo.connected=true;render();return;}state.setupDemo.step=Math.min(6,Number(state.setupDemo.step||0)+1);render();return;}
  if(action==='setup-demo-back'){if(!state.setupDemo)return;state.setupDemo.step=Math.max(0,Number(state.setupDemo.step||0)-1);render();return;}
  if(action==='setup-demo-restart'){if(!state.setupDemo)return;state.setupDemo=createSetupDemoState();render();return;}
  if(action==='setup-demo-finish'){state.setupDemo=null;state.modal=null;render();return;}
  if(action==='setup-demo-jump'){if(!state.setupDemo)return;const target=Number(actionEl.dataset.step||0);if(target<=Number(state.setupDemo.step||0)){state.setupDemo.step=Math.max(0,Math.min(6,target));render();}return;}
  if(action==='setup-demo-toggle-module'){if(!state.setupDemo)return;const key=String(actionEl.dataset.moduleKey||'');if(key&&Object.prototype.hasOwnProperty.call(state.setupDemo.modules,key)){state.setupDemo.modules[key]=!state.setupDemo.modules[key];state.setupDemo.channelsGenerated=false;render();}return;}
  if(action==='setup-demo-channel-mode'){if(!state.setupDemo)return;const mode=String(actionEl.dataset.mode||'quick');state.setupDemo.channelMode=mode==='direct'?'direct':'quick';state.setupDemo.channelsGenerated=false;render();return;}
  if(action==='setup-demo-generate-channels'){if(!state.setupDemo)return;state.setupDemo.channelsGenerated=true;render();return;}
  if(action==='setup-demo-select-visible-members'){
    if(!state.setupDemo)return;
    const groups={member:['m1','m2','m3','m4','m5','m6'],admin:['a1','a2'],guest:['g1','g2','g3','g4','g5','g6','g7','g8','g9','g10']};
    const visible=groups[state.setupDemo.memberFilter]||groups.member;
    const selected=new Set(state.setupDemo.memberSelected||[]);
    const allSelected=visible.every(id=>selected.has(id));
    visible.forEach(id=>allSelected?selected.delete(id):selected.add(id));
    state.setupDemo.memberSelected=[...selected];state.setupDemo.memberImportDone=false;state.setupDemo.memberImportSkipped=false;render();return;
  }
  if(action==='setup-demo-import-members'){
    if(!state.setupDemo)return;
    if(!(state.setupDemo.memberSelected||[]).length){setNotice('등록할 멤버를 한 명 이상 선택해 주세요.');return;}
    state.setupDemo.memberImportDone=true;state.setupDemo.memberImportSkipped=false;render();return;
  }
  if(action==='setup-demo-skip-members'){if(!state.setupDemo)return;state.setupDemo.memberImportDone=true;state.setupDemo.memberImportSkipped=true;render();return;}
  if(action==='open-feedback'){state.modal={type:'feedback'};render();return;}
  if(action==='open-ledger'){clearLedgerPendingFiles();state.modal={type:'ledger',entryId:null};render();return;}
  if(action==='edit-ledger'){clearLedgerPendingFiles();const entryId=actionEl.dataset.entryId;const row=(state.fundSnapshot?.ledger||[]).find(r=>String(r.id)===String(entryId));state.modal={type:row?.can_edit?'ledger':'ledger-correction',entryId};render();return;}
  if(action==='remove-ledger-pending'){const id=String(actionEl.dataset.pendingId||'');const item=(state.ledgerPendingFiles||[]).find(x=>x.id===id);try{if(item?.previewUrl)URL.revokeObjectURL(item.previewUrl);}catch{}state.ledgerPendingFiles=(state.ledgerPendingFiles||[]).filter(x=>x.id!==id);render();return;}
  if(action==='open-ledger-evidence'){const entryId=String(actionEl.dataset.entryId||'');state.modal={type:'ledger-evidence',entryId};render();return;}
  if(action==='open-ledger-attachment'){const path=String(actionEl.dataset.storagePath||'');if(!path)return;await withMutation(async()=>{const url=await getFundEvidenceSignedUrl(path);window.open(url,'_blank','noopener,noreferrer');});return;}
  if(action==='edit-platform-subscription'){if(!state.platformAdmin){setError('PLATFORM OWNER 권한이 필요합니다.');return;}state.modal={type:'platform-subscription',companyId:String(actionEl.dataset.companyId||'')};render();return;}
  if(action==='edit-member'){state.modal={type:'member',membershipId:actionEl.dataset.membershipId};render();return;}
  if(action==='open-asset'){state.modal={type:'asset',assetId:null};render();return;}
  if(action==='edit-asset'){state.modal={type:'asset',assetId:actionEl.dataset.assetId};render();return;}
  if(action==='open-account-request'){state.modal={type:'account'};render();return;}
  if(action==='open-account-row'){const membershipId=String(actionEl.dataset.membershipId||'');state.modal=membershipId===currentMembership(state)?.id?{type:'account'}:{type:'account-detail',membershipId};render();return;}
  if(action==='reset-fund-filter'){state.fundFilters={person:'all',type:'all',account:'all'};render();return;}
  if(action==='open-discord-reconnect'){if(!canAdmin(state)){setError('관리자 권한이 필요합니다.');return;}if(state.discordConnection?.status!=='connected'){setError('현재 연결된 Discord 서버가 없습니다.');return;}state.modal={type:'discord-reconnect'};render();return;}
  await withMutation(async()=>{
    if(action==='discord-login'){await signInWithDiscord();return;}
    if(action==='logout'){clearReconnectPoll();manualSignOutUntil=Date.now()+6000;await signOut();state.modal=null;state.setupGuide=null;return;}
    if(action==='refresh'){await refreshAll();setNotice('최신 데이터를 불러왔습니다.');return;}
    if(action==='refresh-platform'){if(!state.platformAdmin)throw new Error('PLATFORM OWNER 권한이 필요합니다.');await loadCompanies();state.platformSnapshot=await getPlatformCompanies();const changed=applyPlatformCompanyVisibility();if(changed)await loadCompanyData();setNotice('회사 구독 현황을 새로고침했습니다.');return;}
    if(action==='refresh-fund'){await loadFundSnapshot();if(state.fundTab==='weekly')await loadFundWeeklyMonth();setNotice('공금 데이터를 새로고침했습니다.');return;}
    if(action==='connect-discord'){if(!canAdmin(state))throw new Error('관리자 권한이 필요합니다.');if(['reset_requested','resetting'].includes(String(state.onboardingStatus?.status||'')))throw new Error('기존 Discord 연결을 정리 중입니다. 완료 후 다시 연결해 주세요.');const started=await startDiscordConnection(state.companyId);location.assign(started.authorize_url);return;}
    if(action==='toggle-module'){
      if(!canAdmin(state))throw new Error('관리자 권한이 필요합니다.');if(['reset_requested','resetting'].includes(String(state.onboardingStatus?.status||'')))throw new Error('Discord 연결을 정리 중에는 기능 설정을 변경할 수 없습니다.'); const key=actionEl.dataset.moduleKey; const current=moduleRow(state,key); if(!current)throw new Error('기능 설정을 찾지 못했습니다.');
      await setCompanyModule(state.companyId,key,!current.enabled,state.session.user.id); await loadCompanyData(); setNotice(`${(current.enabled?'기능을 껐습니다.':'기능을 켰습니다.')}`); return;
    }
    if(action==='open-cooking-menu'){if(!canAdmin(state))throw new Error('요리 메뉴 관리는 OWNER 또는 관리자만 가능합니다.');state.modal={type:'cooking-menu',typeKey:null};render();return;}
    if(action==='edit-cooking-menu'){if(!canAdmin(state))throw new Error('요리 메뉴 관리는 OWNER 또는 관리자만 가능합니다.');state.modal={type:'cooking-menu',typeKey:String(actionEl.dataset.typeKey||'')};render();return;}
    if(action==='toggle-cooking-menu'){
      if(!canAdmin(state))throw new Error('요리 메뉴 관리는 OWNER 또는 관리자만 가능합니다.');
      const typeKey=String(actionEl.dataset.typeKey||''); const current=state.cookingOrderTypes.find(x=>String(x.type_key)===typeKey);
      if(!current)throw new Error('요리 메뉴를 찾지 못했습니다.');
      await setCookingOrderTypeEnabled(state.companyId,typeKey,current.enabled===false);
      state.cookingOrderTypes=await getCookingOrderTypes(state.companyId);
      setNotice(current.enabled===false?'요리 메뉴를 사용하도록 변경했습니다.':'요리 메뉴를 숨겼습니다.');return;
    }
    if(action==='cancel-ledger'){const id=actionEl.dataset.entryId;if(!window.confirm('이 공금 내역을 취소할까요?'))return;const input=window.prompt('취소 사유를 입력해 주세요.','');if(input===null)return;const reason=input.trim();if(!reason)throw new Error('취소 사유를 입력해 주세요.');await cancelFundLedgerEntry(state.companyId,id,reason);state.modal=null;await loadFundSnapshot();setNotice('공금 내역을 취소했습니다.');return;}
    if(action==='return-asset'){const id=actionEl.dataset.assetId;if(!window.confirm('이 자산을 반납 처리할까요?'))return;const note=window.prompt('반납 메모 (선택)','')??'';await manageWebAsset(state.companyId,id,'return',note);state.modal=null;await loadAssetsAndAccounts();setNotice('자산을 반납 처리했습니다.');return;}
    if(action==='account-review'){const req=actionEl.dataset.requestId;const reviewAction=actionEl.dataset.reviewAction;const note=reviewAction==='reject'?(window.prompt('반려 사유 (선택)','')??''):'';await reviewWebAccountRequest(state.companyId,req,reviewAction,note);await loadAssetsAndAccounts();setNotice(reviewAction==='approve'?'계좌 신청을 승인했습니다.':'계좌 신청을 반려했습니다.');return;}
    if(action==='fund-review'){const req=actionEl.dataset.requestId;const reviewAction=actionEl.dataset.reviewAction;const note=reviewAction!=='approve'?(window.prompt(reviewAction==='reject'?'반려 사유 (선택)':'보류 메모 (선택)','')??''):'';await reviewFundRequest(state.companyId,req,reviewAction,note);await loadFundSnapshot();setNotice(reviewAction==='approve'?'납부를 승인했습니다.':reviewAction==='hold'?'납부 신청을 보류했습니다.':'납부 신청을 반려했습니다.');return;}
    if(action==='open-evidence'){const url=await getFundEvidenceSignedUrl(actionEl.dataset.evidencePath,300);if(url)window.open(url,'_blank','noopener,noreferrer');return;}
  });
});

root.addEventListener('change', async event => {
  try{
    if(event.target.matches('[data-fund-ledger-month]')){state.fundMonth=event.target.value;await withMutation(loadFundSnapshot);return;}
    if(event.target.matches('[data-fund-weekly-month]')){state.fundWeeklyMonth=event.target.value;state.fundMonthlyRows=[];await loadFundWeeklyMonth();return;}
    if(event.target.matches('[data-fund-filter]')){state.fundFilters[event.target.dataset.fundFilter]=event.target.value;render();return;}
    if(event.target.matches('[data-member-role]')){state.memberRole=event.target.value;render();return;}
    if(event.target.matches('[data-asset-category]')){state.assetCategory=event.target.value;render();return;}
    if(event.target.matches('[data-asset-status]')){state.assetStatus=event.target.value;render();return;}
    if(event.target.matches('[data-account-status]')){state.accountStatus=event.target.value;render();return;}
    if(event.target.matches('[data-asset-holder]')){const status=root.querySelector('[data-asset-modal-status]');if(status)status.value=event.target.value?'보유':'미배정';return;}
    if(event.target.matches('[data-asset-modal-status]')){const holder=root.querySelector('[data-asset-holder]');if(event.target.value==='미배정'&&holder)holder.value='';return;}
    if(event.target.matches('[data-guide-role]')){if(!state.setupGuide)return;state.setupGuide[event.target.dataset.guideRole]=String(event.target.value||'');render();return;}
    if(event.target.matches('[data-guide-direct-channel]')){if(!state.setupGuide)return;const key=String(event.target.dataset.guideDirectChannel||'');state.setupGuide.directChannels=state.setupGuide.directChannels||{};state.setupGuide.directChannels[key]=String(event.target.value||'');render();return;}
    if(event.target.matches('[data-guide-category-name]')){if(!state.setupGuide)return;state.setupGuide.categoryName=String(event.target.value||'').trim()||'AXE PRODUCT';render();return;}
    if(event.target.matches('[data-guide-generated-channel]')){if(!state.setupGuide)return;const key=String(event.target.dataset.guideGeneratedChannel||'');state.setupGuide.generatedChannels=state.setupGuide.generatedChannels||{};state.setupGuide.generatedChannels[key]=String(event.target.value||'').replace(/^#+/,'').trim();render();return;}
    if(event.target.matches('[data-guide-member-filter]')){if(!state.setupGuide)return;state.setupGuide.memberFilterRoleId=String(event.target.value||'');state.setupGuide.memberListLoaded=false;state.setupGuide.memberCandidates=[];state.setupGuide.memberSelected=[];if(state.setupGuide.memberFilterRoleId)await withMutation(loadSetupGuideMembers);else render();return;}
    if(event.target.matches('[data-guide-member-target-role]')){if(!state.setupGuide)return;state.setupGuide.memberTargetRole=String(event.target.value||'')==='admin'?'admin':'member';render();return;}
    if(event.target.matches('[data-guide-member-select]')){if(!state.setupGuide)return;const id=String(event.target.dataset.guideMemberSelect||'');const selected=new Set((state.setupGuide.memberSelected||[]).map(String));event.target.checked?selected.add(id):selected.delete(id);state.setupGuide.memberSelected=[...selected];render();return;}
    if(event.target.matches('[data-setup-role]')){if(!state.setupDemo)return;state.setupDemo[event.target.dataset.setupRole]=String(event.target.value||'');render();return;}
    if(event.target.matches('[data-platform-status]')){state.platformStatus=String(event.target.value||'all');render();return;}
    if(event.target.matches('[data-platform-query]')){state.platformQuery=String(event.target.value||'');render();return;}
    if(event.target.matches('[data-ledger-evidence-input]')){addLedgerPendingFiles(event.target.files);event.target.value='';return;}
    if(event.target.matches('[data-setup-channel]')){if(!state.setupDemo)return;const key=String(event.target.dataset.setupChannel||'');state.setupDemo.channels=state.setupDemo.channels||{};const map={'공금현황판':'fund','3시-총알':'ammo3','10시-총알':'ammo10','전적-등록':'outlaw','개조서':'modbook','요리-주문':'cooking'};state.setupDemo.channels[map[key]||key]=String(event.target.value||'');render();return;}
    if(event.target.matches('[data-setup-category-name]')){if(!state.setupDemo)return;state.setupDemo.categoryName=String(event.target.value||'').trim()||'AXE PRODUCT';state.setupDemo.channelsGenerated=false;render();return;}
    if(event.target.matches('[data-setup-generated-channel]')){if(!state.setupDemo)return;const key=String(event.target.dataset.setupGeneratedChannel||'');state.setupDemo.generatedChannels=state.setupDemo.generatedChannels||{};state.setupDemo.generatedChannels[key]=String(event.target.value||'').replace(/^#+/,'').trim();state.setupDemo.channelsGenerated=false;render();return;}
    if(event.target.matches('[data-setup-member-filter]')){
      if(!state.setupDemo)return;
      const filter=String(event.target.value||'member');
      const groups={member:['m1','m2','m3','m4','m5','m6'],admin:['a1','a2'],guest:['g1','g2','g3','g4','g5','g6','g7','g8','g9','g10']};
      state.setupDemo.memberFilter=['member','admin','guest'].includes(filter)?filter:'member';
      state.setupDemo.memberSelected=[...(groups[state.setupDemo.memberFilter]||groups.member)];
      if(state.setupDemo.memberFilter==='admin')state.setupDemo.memberTargetRole='admin';
      if(state.setupDemo.memberFilter==='member')state.setupDemo.memberTargetRole='member';
      state.setupDemo.memberImportDone=false;state.setupDemo.memberImportSkipped=false;render();return;
    }
    if(event.target.matches('[data-setup-member-target-role]')){if(!state.setupDemo)return;state.setupDemo.memberTargetRole=String(event.target.value||'member')==='admin'?'admin':'member';state.setupDemo.memberImportDone=false;state.setupDemo.memberImportSkipped=false;render();return;}
    if(event.target.matches('[data-setup-member-select]')){if(!state.setupDemo)return;const id=String(event.target.dataset.setupMemberSelect||'');const selected=new Set(state.setupDemo.memberSelected||[]);event.target.checked?selected.add(id):selected.delete(id);state.setupDemo.memberSelected=[...selected];state.setupDemo.memberImportDone=false;state.setupDemo.memberImportSkipped=false;render();return;}
  }catch(error){setError(error);}
});
root.addEventListener('input', event => {
  if(event.target.matches('[data-member-query]')){state.memberQuery=event.target.value;const pos=event.target.selectionStart;render();const el=root.querySelector('[data-member-query]');el?.focus();el?.setSelectionRange?.(pos,pos);}
  if(event.target.matches('[data-asset-query]')){state.assetQuery=event.target.value;const pos=event.target.selectionStart;render();const el=root.querySelector('[data-asset-query]');el?.focus();el?.setSelectionRange?.(pos,pos);}
  if(event.target.matches('[data-account-query]')){state.accountQuery=event.target.value;const pos=event.target.selectionStart;render();const el=root.querySelector('[data-account-query]');el?.focus();el?.setSelectionRange?.(pos,pos);}
  if(event.target.matches('[data-platform-query]')){state.platformQuery=event.target.value;const pos=event.target.selectionStart;render();const el=root.querySelector('[data-platform-query]');el?.focus();el?.setSelectionRange?.(pos,pos);}
});

document.addEventListener('click', event => {
  if(state.companyMenuOpen && !event.target.closest('.runtime-company-picker')){state.companyMenuOpen=false;render();}
});

root.addEventListener('paste', event=>{
  if(!event.target.closest('[data-ledger-evidence-drop]')) return;
  const files=Array.from(event.clipboardData?.files||[]).filter(f=>f.type?.startsWith('image/'));
  if(files.length){event.preventDefault();addLedgerPendingFiles(files);}
});
root.addEventListener('dragover', event=>{if(event.target.closest('[data-ledger-evidence-drop]'))event.preventDefault();});
root.addEventListener('drop', event=>{
  if(!event.target.closest('[data-ledger-evidence-drop]')) return;
  event.preventDefault();
  const files=Array.from(event.dataTransfer?.files||[]).filter(f=>f.type?.startsWith('image/'));
  if(files.length)addLedgerPendingFiles(files);
});

root.addEventListener('submit', async event => {
  const form=event.target.closest('form[data-form]'); if(!form)return; event.preventDefault(); const type=form.dataset.form; const data=new FormData(form);
  await withMutation(async()=>{
    if(type==='create-company'){const created=await createCompany(String(data.get('name')||'').trim(),String(data.get('slug')||'').trim());if(!created?.id)throw new Error('생성된 회사 정보를 받지 못했습니다.');state.companyId=created.id;localStorage.setItem('axe_product_company_id',created.id);state.modal=null;state.page='settings';state.settingsTab='basic';localStorage.setItem('axe_product_page','settings');localStorage.setItem('axe_product_settings_tab','basic');await loadCompanies();await loadCompanyData();state.ready=true;await persistSetupGuideProgress(1);state.setupGuide=createSetupGuideState(1);state.modal={type:'setup-guide'};setNotice('새 회사가 생성됐습니다. 초기설정을 이어서 진행해 주세요.');return;}
    if(type==='reconnect-discord'){clearCatalogPoll();if(data.get('confirm')!=='yes')throw new Error('Discord 연결 초기화 안내를 확인해 주세요.');const jobId=await requestCompanyDiscordReconnect(state.companyId);state.modal=null;state.onboardingStatus=await getCompanyOnboardingStatus(state.companyId);setNotice(`Discord 연결 정리를 시작했습니다. 작업 ${jobId.slice(0,8)}…`);startReconnectStatusPoll();return;}
    if(type==='feedback'){const result=await submitProductFeedback(state.companyId,String(data.get('category')),String(data.get('title')||'').trim(),String(data.get('detail')||'').trim(),String(data.get('contact')||'').trim());state.modal=null;setNotice(`피드백을 보냈습니다. 접수번호 ${result?.reference||''}`);return;}
    if(type==='ledger'){const existingId=String(data.get('entry_id')||'')||null;const payload={entryId:existingId,direction:String(data.get('direction')||''),amount:Number(data.get('amount')||0),account:String(data.get('account')||'공용계좌'),category:String(data.get('category')||'').trim(),membershipId:String(data.get('membership_id')||'')||null,memo:String(data.get('memo')||'').trim(),ledgerDate:String(data.get('ledger_date')||'')};const hadEvidence=(state.ledgerPendingFiles||[]).length>0;const saved=await saveFundLedgerEntry(state.companyId,payload);let entryId=existingId||ledgerEntryIdFromSave(saved);if((state.ledgerPendingFiles||[]).length&&!entryId){const [yy,mm]=payload.ledgerDate.split('-').map(Number);const fresh=await getFundTreasurySnapshot(state.companyId,yy||null,mm||null,200);const signed=payload.direction==='지출'?-Math.abs(payload.amount):Math.abs(payload.amount);const matches=(fresh?.ledger||[]).filter(r=>String(r.category||'')===payload.category&&String(r.account||'')===payload.account&&dateKey(r.ledger_date)===payload.ledgerDate&&Number(r.amount||0)===signed);entryId=String(matches.sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')))[0]?.id||'');}if((state.ledgerPendingFiles||[]).length&&!entryId)throw new Error('내역은 저장됐지만 첨부사진 연결 대상을 확인하지 못했습니다. 해당 내역의 수정 화면에서 사진만 다시 첨부해 주세요.');if(entryId)await uploadLedgerPendingEvidence(entryId);clearLedgerPendingFiles();state.modal=null;await loadFundSnapshot();setNotice(hadEvidence?'공금 내역과 첨부사진을 저장했습니다.':'공금 내역을 저장했습니다.');return;}
    if(type==='ledger-correction'){const entryId=String(data.get('entry_id')||'');const row=(state.fundSnapshot?.ledger||[]).find(r=>String(r.id)===entryId);if(!row)throw new Error('정정할 공금 내역을 찾지 못했습니다.');const oldSigned=Number(row.amount||0);const targetAmount=Math.abs(Number(data.get('amount')||0));if(!Number.isFinite(targetAmount)||targetAmount<=0)throw new Error('최종 금액을 확인해 주세요.');const targetDirection=String(data.get('direction')||'수입');const targetSigned=targetDirection==='지출'?-targetAmount:targetAmount;const delta=targetSigned-oldSigned;if(delta===0)throw new Error('현재 금액과 동일합니다. 변경할 금액 또는 구분을 입력해 주세요.');const reason=String(data.get('reason')||'').trim();if(!reason)throw new Error('정정 사유를 입력해 주세요.');const correctionPayload={entryId:null,direction:delta<0?'지출':'수입',amount:Math.abs(delta),account:String(row.account||'공용계좌'),category:`${row.entry_type==='payment'?'주간공금':(row.category||'공금')} 정정`,membershipId:String(row.membership_id||'')||null,memo:`원본 ${entryId.slice(0,8)} 정정 · ${reason}`,ledgerDate:String(data.get('ledger_date')||dateKey(new Date()))};const hadEvidence=(state.ledgerPendingFiles||[]).length>0;const saved=await saveFundLedgerEntry(state.companyId,correctionPayload);let correctionId=ledgerEntryIdFromSave(saved);if(hadEvidence&&!correctionId){const [yy,mm]=correctionPayload.ledgerDate.split('-').map(Number);const fresh=await getFundTreasurySnapshot(state.companyId,yy||null,mm||null,200);const signed=correctionPayload.direction==='지출'?-Math.abs(correctionPayload.amount):Math.abs(correctionPayload.amount);const matches=(fresh?.ledger||[]).filter(r=>String(r.category||'')===correctionPayload.category&&String(r.account||'')===correctionPayload.account&&dateKey(r.ledger_date)===correctionPayload.ledgerDate&&Number(r.amount||0)===signed&&String(r.memo||'')===correctionPayload.memo);correctionId=String(matches.sort((a,b)=>String(b.created_at||'').localeCompare(String(a.created_at||'')))[0]?.id||'');}if(hadEvidence&&!correctionId)throw new Error('정정은 반영됐지만 첨부사진 연결 대상을 확인하지 못했습니다. 새 정정 내역의 수정 화면에서 사진을 다시 첨부해 주세요.');if(correctionId)await uploadLedgerPendingEvidence(correctionId);clearLedgerPendingFiles();state.modal=null;await loadFundSnapshot();setNotice(hadEvidence?'정정 차액과 첨부사진을 반영했습니다.':'원본을 보존한 상태로 정정 차액을 반영했습니다.');return;}
    if(type==='platform-subscription'){if(!state.platformAdmin)throw new Error('PLATFORM OWNER 권한이 필요합니다.');const companyId=String(data.get('company_id')||'');const toIso=(v,end=false)=>{const s=String(v||'').trim();if(!s)return null;return new Date(`${s}T${end?'23:59:59':'00:00:00'}+09:00`).toISOString();};await updatePlatformSubscription(companyId,{plan:String(data.get('plan')||'standard'),status:String(data.get('status')||'active'),startsAt:toIso(data.get('starts_at')),endsAt:toIso(data.get('ends_at'),true),graceUntil:toIso(data.get('grace_until'),true),memo:String(data.get('memo')||'').trim()});await loadCompanies();state.platformSnapshot=await getPlatformCompanies();const changed=applyPlatformCompanyVisibility();if(changed)await loadCompanyData();state.modal=null;setNotice('구독 정보를 저장했습니다.');return;}
    if(type==='member'){const id=String(data.get('membership_id'));const row=state.memberships.find(m=>m.id===id);const role=String(data.get('role'));const status=String(data.get('status'));const aliasName=String(data.get('alias_name')||'').trim();const employmentStartedOn=String(data.get('employment_started_on')||'');const memberNote=String(data.get('member_note')||'').trim();if(String(row.alias_name||'')!==aliasName)await updateMembershipAlias(id,aliasName);if(row.role!==role)await updateMembershipRole(id,role);if(row.status!==status)await updateMembershipStatus(id,status);if(String(row.employment_started_on||'')!==employmentStartedOn)await updateMembershipEmploymentDate(id,employmentStartedOn);if(String(row.member_note||'')!==memberNote)await updateMembershipNote(id,memberNote);state.modal=null;await loadCompanyData();setNotice('멤버 정보를 저장했습니다.');return;}
    if(type==='asset'){let membershipId=String(data.get('membership_id')||'')||null;let status=String(data.get('status')||'').trim()||(membershipId?'보유':'미배정');if(status==='미배정')membershipId=null;if(membershipId)status='보유';const holder=membershipId?(state.assetsSnapshot?.members||[]).find(m=>m.id===membershipId):null;const assetId=String(data.get('asset_id')||'')||null;const existing=assetId?(state.assetsSnapshot?.assets||[]).find(a=>a.id===assetId):null;await saveWebAsset(state.companyId,{assetId,legacyNo:existing?.legacy_no||null,membershipId,ownerName:holder?.display_name||'미배정',category:String(data.get('asset_category')||'기타').trim(),name:String(data.get('asset_name')||'').trim(),acquisitionMethod:String(data.get('acquisition_method')||'').trim()||null,status,note:String(data.get('note')||'').trim()||null});state.modal=null;await loadAssetsAndAccounts();setNotice(membershipId?'자산을 저장하고 보유자를 배정했습니다.':'자산을 미배정 상태로 저장했습니다.');return;}
    if(type==='account-request'){await submitWebAccountRequest(state.companyId,String(data.get('account')||''),String(data.get('note')||''));state.modal=null;await loadAssetsAndAccounts();setNotice('계좌 등록·변경 신청을 제출했습니다.');return;}
    if(type==='fund-balance'){const game=Number(data.get('game_balance'));if(!Number.isFinite(game)||game<0)throw new Error('게임 내 공용계좌 잔액을 확인해 주세요.');const settings={...(state.companySettings?.settings||{}),fund_balance_check:{game_balance:game,note:String(data.get('note')||'').trim(),calculated_balance:Number(state.fundSnapshot?.balance?.public||0),checked_at:new Date().toISOString()}};await updateCompanySettings(state.companyId,{settings},state.session.user.id);state.companySettings=await getCompanySettings(state.companyId);setNotice('잔액 점검을 저장했습니다.');return;}
    if(type==='fund-fee-rule'){const feeMonth=String(data.get('fee_month')||state.fundMonth||state.currentMonth);const [feeYear,feeMonthNo]=feeMonth.split('-').map(Number);if(!feeYear||!feeMonthNo)throw new Error('적용 월을 확인해 주세요.');await setFundFeeRule(state.companyId,feeYear,feeMonthNo,Number(data.get('week')),Number(data.get('weekly_fee')),'WEB 공금 설정');const settings={...(state.companySettings?.settings||{}),fund_default_account:String(data.get('default_account')||'공용계좌')};await updateCompanySettings(state.companyId,{settings},state.session.user.id);state.companySettings=await getCompanySettings(state.companyId);state.fundMonth=feeMonth;await loadFundSnapshot();setNotice(`${feeYear}년 ${feeMonthNo}월 공금 설정을 저장했습니다.`);return;}
    if(type==='cooking-guide'){
      if(!canAdmin(state))throw new Error('요리 주문 안내 관리는 OWNER 또는 관리자만 가능합니다.');
      const membershipId=currentMembership(state)?.id||null;
      if(!membershipId)throw new Error('현재 회사 멤버 정보를 확인하지 못했습니다.');
      state.cookingDiscordConfig=await saveCookingDiscordGuide(state.companyId,{
        scheduleText:String(data.get('schedule_text')||''),
        extraGuide:String(data.get('extra_guide')||''),
      },membershipId);
      setNotice('Discord 요리 주문 안내를 저장했습니다.');return;
    }
    if(type==='cooking-menu'){
      if(!canAdmin(state))throw new Error('요리 메뉴 관리는 OWNER 또는 관리자만 가능합니다.');
      const existingKey=String(data.get('type_key')||'').trim();
      const randomPart=(globalThis.crypto?.randomUUID?.()||`${Date.now().toString(36)}_${Math.random().toString(36).slice(2)}`).replace(/-/g,'').slice(0,12);
      const typeKey=existingKey||`m_${randomPart}`;
      const label=String(data.get('label')||'').trim(); const shortLabel=String(data.get('short_label')||'').trim();
      if(!label)throw new Error('메뉴 이름을 입력해 주세요.');
      await saveCookingOrderType(state.companyId,{typeKey,label,shortLabel:shortLabel||label,detail:String(data.get('detail')||'').trim(),pricePerSet:Number(data.get('price_per_set')||0),sortOrder:Number(data.get('sort_order')||0),enabled:data.get('enabled')==='on'});
      state.cookingOrderTypes=await getCookingOrderTypes(state.companyId); state.modal=null;
      setNotice(existingKey?'요리 메뉴를 저장했습니다.':'요리 메뉴를 추가했습니다.');return;
    }
    if(type==='settings-basic'){
      const wasRoleStep=isOnboardingStep('roles');
      await saveBasicSettingsData(data,{requireOnboardingRoles:wasRoleStep});
      await loadCompanies();
      await loadBaseCompanyData();
      if(wasRoleStep || state.onboardingStatus?.current_step==='modules'){
        state.settingsTab='modules';
        localStorage.setItem('axe_product_settings_tab','modules');
      }
      setNotice(wasRoleStep?'역할 설정을 저장했습니다. 기능·채널 설정으로 이동합니다.':'기본 정보를 저장했습니다.');return;
    }
    if(type==='settings-modules'){
      const wasModuleStep=isOnboardingStep('modules');
      await saveModuleSettingsData(form,data);
      await loadBaseCompanyData();
      const completed=wasModuleStep && (String(state.onboardingStatus?.status||'')==='ready' || String(state.onboardingStatus?.current_step||'')==='complete');
      setNotice(completed?'초기 설정이 완료됐습니다.':'기능 설정을 저장했습니다.');return;
    }
  });
});

cleanupLegacyPwa();
boot();
